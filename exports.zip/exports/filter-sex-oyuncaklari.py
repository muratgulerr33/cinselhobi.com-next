import csv

# Ağaç yapısındaki geçerli alt kategoriler (sex-oyuncaklari altında)
valid_categories = {
    'realistik-vibratorler',
    'et-dokulu-urunler',
    'realistik-dildolar',
    'sex-makinalari',
    'modern-vibratorler',
    'belden-baglamalilar'
}

input_file = 'exports/sex-oyuncaklari.csv'
output_file = 'exports/sex-oyuncaklari.csv'

wrong_products = []

with open(input_file, 'r', encoding='utf-8') as f:
    reader = csv.DictReader(f)
    fieldnames = reader.fieldnames
    
    for row in reader:
        categories = row.get('categories', '')
        if 'sex-oyuncaklari' in categories:
            # Kategorileri virgülle ayır ve temizle
            cat_list = [cat.strip() for cat in categories.split(',')]
            
            # sex-oyuncaklari'yı çıkar
            other_cats = [cat for cat in cat_list if cat != 'sex-oyuncaklari']
            
            # Eğer başka kategoriler varsa
            if other_cats:
                # Bu kategorilerden herhangi biri geçersiz mi kontrol et
                has_invalid = any(cat not in valid_categories for cat in other_cats)
                
                if has_invalid:
                    wrong_products.append(row)

# Dosyayı yeniden yaz
with open(output_file, 'w', encoding='utf-8', newline='') as f:
    writer = csv.DictWriter(f, fieldnames=fieldnames)
    writer.writeheader()
    writer.writerows(wrong_products)

print(f"Toplam {len(wrong_products)} gerçekten yanlış ilişkilendirilmiş ürün kaldı.")
print(f"Geçerli kategorilerle ilişkilendirilmiş ürünler çıkarıldı.")
