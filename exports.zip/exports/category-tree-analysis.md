# Kategori Ağacı + Ürün Sayımları Analiz Raporu

**Oluşturulma Tarihi:** 15.01.2026 04:42:26

---

## 0. Baseline Sağlık Kontrolü

**Durum:** ✅ PASS

| Metrik | Gerçek | Hedef | Durum |
|--------|--------|-------|-------|
| Publish + Instock | 244 | 244 | ✅ |
| Publish + Outofstock | 30 | 30 | ✅ |
| Publish Total | 274 | 274 | ✅ |

> **Not:** UI kararları bu baseline sayılarına göre kilitlenmiştir.

---

## 0.1 Şema Doğrulama

**Durum:** ✅ Geçerli

### Tablolar ve Kolonlar

**categories:** id, wc_id, slug, name, parent_wc_id, description, image_url, created_at, updated_at

**products:** id, wc_id, slug, name, status, type, sku, price, regular_price, sale_price, currency, short_description, description, stock_status, stock_quantity, images, raw, created_at, updated_at

**product_categories:** product_id, category_id

---

## 1. Genel Metrikler

- **Toplam Kategori Sayısı:** 26
- **Top-Level Kategori Sayısı:** 9
- **Child Kategori Sayısı:** 17
- **Max Depth:** 1

## 2. Kategori İstatistikleri

| ID | Slug | Name | Depth | Top-Level | Direct Total | Direct Publish | Direct Instock | Children Count |
|----|------|------|-------|-----------|--------------|----------------|----------------|----------------|
| 1 | anal-oyuncaklar | ANAL OYUNCAKLAR | 0 | ✓ | 22 | 22 | 21 | 0 |
| 2 | bayan-istek-arttiricilar | Bayan İstek Arttırıcılar | 1 |  | 4 | 4 | 3 | 0 |
| 3 | belden-baglamalilar | Belden Bağlamalılar | 1 |  | 19 | 19 | 18 | 0 |
| 4 | erkeklere-ozel | ERKEKLERE ÖZEL | 0 | ✓ | 54 | 54 | 50 | 4 |
| 5 | et-dokulu-urunler | Et Dokulu Ürünler | 1 |  | 15 | 15 | 14 | 0 |
| 6 | fantezi-aksesuarlar | FANTEZİ AKSESUARLAR | 0 | ✓ | 0 | 0 | 0 | 0 |
| 7 | fantezi-giyim | Fantezi Giyim | 1 |  | 22 | 22 | 13 | 0 |
| 8 | fetis-fantezi | Fetiş ve Fantezi | 1 |  | 34 | 34 | 28 | 0 |
| 9 | geciktiriciler | GECİKTİRİCİLER | 0 | ✓ | 7 | 7 | 7 | 0 |
| 10 | halka-kiliflar | Halka ve Kılıflar | 1 |  | 16 | 16 | 15 | 0 |
| 11 | kadinlara-ozel | KADINLARA ÖZEL | 0 | ✓ | 60 | 60 | 44 | 4 |
| 12 | kayganlastirici-jeller | KAYGANLAŞTIRICI JELLER | 0 | ✓ | 8 | 8 | 8 | 0 |
| 13 | kozmetik | KOZMETİK | 0 | ✓ | 0 | 0 | 0 | 3 |
| 14 | masaj-yaglari | Masaj Yağları | 1 |  | 2 | 2 | 0 | 0 |
| 15 | modern-vibratorler | Modern Vibratörler | 1 |  | 21 | 21 | 20 | 0 |
| 16 | parfumler | Parfümler | 1 |  | 0 | 0 | 0 | 0 |
| 17 | penis-pompalari | Penis Pompaları | 1 |  | 2 | 2 | 2 | 0 |
| 18 | prezervatifler | Prezervatifler | 1 |  | 14 | 14 | 13 | 0 |
| 19 | realistik-dildolar | Realistik Dildolar | 1 |  | 28 | 28 | 26 | 0 |
| 20 | realistik-mankenler | REALİSTİK MANKENLER | 0 | ✓ | 7 | 7 | 7 | 0 |
| 21 | realistik-vibratorler | Realistik Vibratörler | 1 |  | 17 | 17 | 16 | 0 |
| 22 | sex-makineleri | Sex Makinaları | 1 |  | 0 | 0 | 0 | 0 |
| 23 | sex-oyuncaklari | SEX OYUNCAKLARI | 0 | ✓ | 97 | 97 | 91 | 6 |
| 24 | sisme-erkekler | Şişme Erkekler | 1 |  | 0 | 0 | 0 | 0 |
| 25 | sisme-kadinlar | Şişme Kadınlar | 1 |  | 8 | 8 | 8 | 0 |
| 26 | suni-vajina-masturbatorler | Suni Vajina Mastürbatörler | 1 |  | 28 | 28 | 25 | 0 |

## 3. Top-Level Kategori Rollup Hesapları

| ID | Slug | Name | Direct Instock | Desc Instock | Overlap Instock | Rolled Up Unique Instock |
|----|------|------|----------------|--------------|-----------------|--------------------------|
| 1 | anal-oyuncaklar | ANAL OYUNCAKLAR | 21 | 0 | 0 | 21 |
| 4 | erkeklere-ozel | ERKEKLERE ÖZEL | 50 | 50 | 50 | 50 |
| 6 | fantezi-aksesuarlar | FANTEZİ AKSESUARLAR | 0 | 0 | 0 | 0 |
| 9 | geciktiriciler | GECİKTİRİCİLER | 7 | 0 | 0 | 7 |
| 11 | kadinlara-ozel | KADINLARA ÖZEL | 44 | 44 | 44 | 44 |
| 12 | kayganlastirici-jeller | KAYGANLAŞTIRICI JELLER | 8 | 0 | 0 | 8 |
| 13 | kozmetik | KOZMETİK | 0 | 13 | 0 | 13 |
| 20 | realistik-mankenler | REALİSTİK MANKENLER | 7 | 0 | 0 | 7 |
| 23 | sex-oyuncaklari | SEX OYUNCAKLARI | 91 | 94 | 91 | 94 |

## 4. Karmaşa Tespiti

### 4.1 Double-Link (Parent + Child Overlap)

**Toplam:** 211

| Product ID | Product Slug | Parent Category | Child Category |
|------------|--------------|-----------------|----------------|
| 1 | 2-si-1-arada-titresimli-realistik-catal-vibrator | SEX OYUNCAKLARI (23) | Modern Vibratörler (15) |
| 2 | uzaktan-kumandali-masaj-vibratoru | SEX OYUNCAKLARI (23) | Modern Vibratörler (15) |
| 3 | 3-boyutlu-suni-vajina-masturbator-kirmizi | ERKEKLERE ÖZEL (4) | Suni Vajina Mastürbatörler (26) |
| 4 | 3-boyutlu-suni-vajina-masturbator-mavi | ERKEKLERE ÖZEL (4) | Suni Vajina Mastürbatörler (26) |
| 5 | 3-boyutlu-suni-vajina-masturbator-mor | ERKEKLERE ÖZEL (4) | Suni Vajina Mastürbatörler (26) |
| 7 | angel-sisme-bebek | ERKEKLERE ÖZEL (4) | Şişme Kadınlar (25) |
| 11 | eroshop-love-clone-et-doku-penis | SEX OYUNCAKLARI (23) | Realistik Vibratörler (21) |
| 12 | candy-love-doll-3-islevli-sisme-bebek | ERKEKLERE ÖZEL (4) | Şişme Kadınlar (25) |
| 13 | enduro-blaster-penis | SEX OYUNCAKLARI (23) | Realistik Dildolar (19) |
| 14 | eroshop-20cm-gercekci-vibrator | SEX OYUNCAKLARI (23) | Realistik Vibratörler (21) |
| 15 | eroshop-alexs-penis | SEX OYUNCAKLARI (23) | Realistik Dildolar (19) |
| 16 | eroshop-bella-strapon | SEX OYUNCAKLARI (23) | Belden Bağlamalılar (3) |
| 17 | eroshop-pussix-vibe-titresimli-suni-vajina-masturbator | ERKEKLERE ÖZEL (4) | Suni Vajina Mastürbatörler (26) |
| 18 | passion-cup-vajina | ERKEKLERE ÖZEL (4) | Suni Vajina Mastürbatörler (26) |
| 19 | eroshop-siyah-19-cm-esnek-penis-dildo | SEX OYUNCAKLARI (23) | Realistik Dildolar (19) |
| 42 | fetis-fantezi-mor-peluslu-metal-kelepce | KADINLARA ÖZEL (11) | Fetiş ve Fantezi (8) |
| 43 | deri-kirmizi-kelepce | KADINLARA ÖZEL (11) | Fetiş ve Fantezi (8) |
| 44 | fantazi-liseli-kiz-kostumu-corap-hediyeli | KADINLARA ÖZEL (11) | Fetiş ve Fantezi (8) |
| 45 | fantazi-liseli-kiz-kostumu | KADINLARA ÖZEL (11) | Fantezi Giyim (7) |
| 46 | seksi-ekose-etekli-bustiyerli-fantazi-kostum | KADINLARA ÖZEL (11) | Fantezi Giyim (7) |

*... ve 191 tane daha (CSV'de tam liste)*

### 4.2 Multi-Leaf (Ürün 2+ Leaf Kategoride)

**Toplam:** 0

> **Not:** Leaf = depth=1 child kategoriler + children_count=0 top-level kategoriler


### 4.3 Multi-Top-Level (Ürün 2+ Top-Level Kategoride)

**Toplam:** 0

> **Not:** Hub mantığı için bilinçli olabilir ama raporlanmalı.


### 4.4 Orphan Products (Kategorisiz Ürünler)

**Toplam:** 0


### 4.5 Empty Categories (Ürünsüz Kategoriler)

**Toplam:** 5

| Category ID | Slug | Name |
|-------------|------|------|
| 6 | fantezi-aksesuarlar | FANTEZİ AKSESUARLAR |
| 13 | kozmetik | KOZMETİK |
| 16 | parfumler | Parfümler |
| 22 | sex-makineleri | Sex Makinaları |
| 24 | sisme-erkekler | Şişme Erkekler |

### 4.6 Instock=0 Ama Ürün Olan Kategoriler

**Toplam:** 1

| Category ID | Slug | Name | Total Products | Publish Products | Instock Products |
|-------------|------|------|----------------|------------------|------------------|
| 14 | masaj-yaglari | Masaj Yağları | 2 | 2 | 0 |

---

## 5. UI Kararları için Yorum

### 5.1 Empty Categories

**Öneri:** Empty category'ler UI'da gizlenmeli (DB'den silinmemeli).

**Etkilenen Kategoriler:** 5 adet

### 5.2 Instock=0 Ama Ürün Olan Kategoriler

**Öneri:** Bu kategorilerde kategori sayfasında "0 ürün" davranışı netleştirilmeli.

**Etkilenen Kategoriler:** 1 adet

### 5.3 Double-Link (Parent + Child Overlap)

**Durum:** 211 ürün hem parent hem child kategoriye bağlı.

**Politika Seçenekleri:**

1. **Hub Tasarımı:** Parent kategori "hub" olarak kullanılacaksa, double-link kalabilir (ama sayımda unique gösterilmeli).

2. **Leaf-Only Tasarımı:** "1 ürün 1 leaf" istenecekse, parent linklerini toplu kaldırma planı üretilmeli (ayrı iş/ayrı PR).

> **Not:** Bu karar ayrı kilit toplantısı gerektirir.

### 5.4 Multi-Leaf ve Multi-Top-Level

**Multi-Leaf:** 0 ürün 2+ leaf kategoride.

**Multi-Top-Level:** 0 ürün 2+ top-level kategoride.

**Öneri:** Bu durumlar "unique instock" hesabını bozabilir. UI tasarımında dikkate alınmalı.

---

## 6. Cleanup Önerisi (DB'ye Dokunmadan)

> **UYARI:** Aşağıdaki öneriler sadece bilgilendirme amaçlıdır. DB değişikliği gereken işler için backup + plan/apply/verify kuralı zorunludur.

### 6.1 Parent+Child Double-Link Politikası

**Seçenek A - Hub Tasarımı:**
- Parent kategoriler "hub" olarak kullanılacaksa, double-link kalabilir.
- Sayımda unique gösterilmeli (rolled-up unique instock kullanılmalı).
- UI'da parent kategori sayfasında hem direct hem descendant ürünler gösterilebilir.

**Seçenek B - Leaf-Only Tasarımı:**
- "1 ürün 1 leaf" istenecekse, parent linklerini toplu kaldırma planı üretilmeli.
- Bu işlem ayrı bir iş/ayrı PR olarak yapılmalı.
- Backup + plan/apply/verify kuralı zorunlu.

### 6.2 Empty Category'ler

- **DB Değişikliği:** Gerekli değil.
- **UI Değişikliği:** Empty category'ler UI'da gizlenmeli.
- **Filtreleme:** Kategori listesinde sadece direct_total > 0 olanlar gösterilmeli.

### 6.3 Instock=0 Ama Ürün Olan Kategoriler

- **DB Değişikliği:** Gerekli değil.
- **UI Değişikliği:** Kategori sayfasında "0 ürün" davranışı netleştirilmeli.
- **Örnek:** "Bu kategoride şu anda stokta ürün bulunmamaktadır" mesajı gösterilebilir.

---

## 7. CSV Export Dosyaları

Detaylı CSV export'lar `exports/` klasöründe mevcuttur:

- `category-stats.csv` - Her kategori için direct ürün sayımları
- `top-level-rollups.csv` - Top-level kategoriler için rollup hesapları
- `double-links.csv` - Parent+child double-link listesi
- `multi-leaf.csv` - 2+ leaf kategoride olan ürünler
- `multi-top-level.csv` - 2+ top-level kategoride olan ürünler
- `orphan-products.csv` - Kategorisiz ürünler
- `empty-categories.csv` - Ürünsüz kategoriler
- `instock-zero-but-has-products.csv` - Instock=0 ama ürün olan kategoriler

